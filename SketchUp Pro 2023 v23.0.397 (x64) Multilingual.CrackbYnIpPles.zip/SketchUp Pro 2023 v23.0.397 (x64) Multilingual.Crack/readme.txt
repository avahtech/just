INSTRUCTIONS
~~~~~~~~~~~~
1) Install SketchUp Pro 2023
2) Copy patch to installation directory (not recommended)
3) Open patch as admin, apply it will Patch SketchUp.exe Auto
then ask for location choose manually target LayOut.exe in folder C:\Program Files\SketchUp\SketchUp 2023\LayOut
and target Style Builder.exe in folder C:\Program Files\SketchUp\SketchUp 2023\Style Builder

Done!

3nj0y!
--
Cr4ck3d by H Hayat
